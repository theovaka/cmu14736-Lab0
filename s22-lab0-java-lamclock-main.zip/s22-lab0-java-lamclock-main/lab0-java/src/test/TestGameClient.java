package test;

import java.io.*;
import java.net.Socket;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.Scanner;

/**
 * Test game client.
 * This game client sends request to and reads responses from GameServer
 */
public class TestGameClient {
    static String letters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    public Player p;
    private BufferedReader bufferedReader;
    private Socket s;
    private BufferedWriter out;

    public TestGameClient(String addr, String name) {
        String[] splitAddr = addr.split(":", 2);

        try {
            s = new Socket(splitAddr[0], Integer.parseInt(splitAddr[1]));

            // Socket ready to use
            System.out.println(String.format("GameClient %s ready to connect", name));
            out = new BufferedWriter(new OutputStreamWriter(s.getOutputStream()));
            bufferedReader = new BufferedReader(new InputStreamReader(s.getInputStream()));
        } catch (UnknownHostException e) {
            System.out.println("Invalid server address: " + e.getMessage());
        } catch (IOException e) {
            System.out.println("I/O error: " + e.getMessage());
        }

        p = new Player(name, s);
    }

    public void stop() {
        try {
            bufferedReader.close();
            out.close();
            s.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    /**
     * Sends request to server
     *
     * @param msg message to be sent
     */
    protected void send(String msg) {
        try {
            if (s != null) {
                out.write(msg);
                out.flush();
            }
        } catch (IOException e) {
            System.out.println(e);
        }
    }

    protected void SendHello() {
        String payload = String.format("HELLO %s\n", p.uname);
        send(payload);
    }

    protected void SendNewGame(String tag) {
        String payload = String.format("NEW_GAME %s\n", tag);
        send(payload);
    }

    protected void SendJoinGame(String tag) {
        String payload = String.format("JOIN_GAME %s\n", tag);
        send(payload);
    }

    protected void SendStartGame(String tag) {
        String payload = String.format("START_GAME %s\n", tag);
        send(payload);
    }

    protected void SendFileUpload(String tag, String fileName, long fileSize) {
        String file_path = System.getProperty("user.dir") + "/s22-lab0-java-lamclock/lab0-java/src/test/" + fileName;

        Scanner myReader;
        try {
            myReader = new Scanner(new File(file_path));

            StringBuilder content = new StringBuilder();
            while (myReader.hasNextLine()) {
                content.append(myReader.nextLine() + " ");
            }
            myReader.close();

            String payload = String.format("FILE_UPLOAD %s %s %s %s\n", tag, fileName, fileSize, content);
            send(payload);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

    }

    protected void SendRandomWord(String tag, String randomWord) {
        String payload = String.format("RANDOM_WORD %s %s\n", tag, randomWord);
        send(payload);
    }

    protected void SendGuessCount(String tag, int guess) {
        String payload = String.format("WORD_COUNT %s %d\n", tag, guess);
        send(payload);
    }

    protected void SendClose(String tag) {
        String payload = String.format("CLOSE %s\n", tag);
        send(payload);
    }

    protected void SendRestart(String tag) {
        String payload = String.format("RESTART %s\n", tag);
        send(payload);
    }

    protected void SendGoodbye() {
        send("GOODBYE\n");
    }

    /**
     * Reads responses from server
     *
     * @return string representation of the response
     */
    protected String ReadResponse() {
        String responseString = "";

        try {
            responseString = bufferedReader.readLine();
            while (responseString != null && responseString.length() == 0)
                responseString = bufferedReader.readLine();

        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return responseString;
    }


}

/**
 * Individual player in the game
 */
class Player {
    public String uname;
    public Socket sock;

    public Player(String name, Socket s) {
        this.uname = name;
        this.sock = s;
    }
}
