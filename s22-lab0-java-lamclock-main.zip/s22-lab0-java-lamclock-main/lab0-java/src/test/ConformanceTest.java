package test;

import org.junit.Test;

import java.util.Random;

import static org.junit.Assert.assertEquals;


/**
 * Run GameServer in one terminal, and run ConformanceTest in another
 */
public class ConformanceTest {
    private static final TestGameClient invalidPlayer = new TestGameClient("localhost:5100", "");
    private static final TestGameClient wrongArgPlayer = new TestGameClient("localhost:5100", "bad_player");


    @Test
    protected static void TestCheckPoint_Hello() {
        TestGame testGame = new TestGame(2);
        testGame.GameSetup();

        wrongArgPlayer.send(String.format("HELLO bad_player invalid\n"));
        assertEquals("Invalid arguments for command HELLO", wrongArgPlayer.ReadResponse());

        invalidPlayer.SendHello();
        assertEquals("Invalid user name. Try again.", invalidPlayer.ReadResponse());

        System.out.println("TestCheckPoint_Hello PASSED......\n");
    }

    @Test
    protected static void TestCheckPoint_NewGame() {
        wrongArgPlayer.send(String.format("NEW_GAME tag invalid\n"));
        assertEquals("Invalid arguments for command NEW_GAME", wrongArgPlayer.ReadResponse());

        TestGame testGame = new TestGame(8);
        testGame.GameSetup();
        testGame.NewGame();

        invalidPlayer.SendNewGame(testGame.tag);
        assertEquals("The game needs to start with HELLO!", invalidPlayer.ReadResponse());


        testGame.cleanUp();
        System.out.println("TestCheckPoint_NewGame PASSED......\n");
    }

    @Test
    protected static void TestCheckPoint_JoinGame() {
        wrongArgPlayer.send(String.format("JOIN_GAME\n"));
        assertEquals("Invalid arguments for command JOIN_GAME", wrongArgPlayer.ReadResponse());

        TestGame testGame = new TestGame(10);
        testGame.GameSetup();
        testGame.NewGame();
        testGame.JoinGame();

        TestGameClient flakyClient = testGame.players.get(1);
        testGame.DisconnectPlayer(flakyClient);

        TestGame.PlayerThread t = new TestGame.PlayerThread("localhost:5100", "1");
        t.player.SendJoinGame(testGame.tag);
        assertEquals("The game needs to start with HELLO!", t.player.ReadResponse());

        testGame.cleanUp();
        System.out.println("TestCheckPoint_JoinGame PASSED......\n");
    }

    @Test
    protected static void TestCheckPoint_StartGame() {
        wrongArgPlayer.send(String.format("START_GAME tag invalid invalid\n"));
        assertEquals("Invalid arguments for command START_GAME", wrongArgPlayer.ReadResponse());

        TestGame testGame = new TestGame(8);
        testGame.GameSetup();
        testGame.NewGame();

        TestGameClient leader = testGame.players.get(0);
        TestGameClient badPlayer = testGame.players.get(1);

        badPlayer.SendStartGame("BAD");
        String expectedErrorResponse = "Game BAD doesn't exist! Please enter correct tag or try creating a new game.";
        assertEquals(expectedErrorResponse, badPlayer.ReadResponse());

        badPlayer.SendStartGame(testGame.tag);
        expectedErrorResponse = String.format("Only the leader can start the game. Please contact %s", leader.p.uname);
        assertEquals(expectedErrorResponse, badPlayer.ReadResponse());

        leader.SendStartGame(testGame.tag);
        expectedErrorResponse = String.format("Can't start the game %s, waiting for 3 more players.", testGame.tag);
        assertEquals(expectedErrorResponse, leader.ReadResponse());

        testGame.JoinGame();
        testGame.StartGame();

        leader.SendStartGame(testGame.tag);
        expectedErrorResponse = String.format("Game %s has already started! Please try creating a new game.", testGame.tag);
        assertEquals(expectedErrorResponse, leader.ReadResponse());

        testGame.cleanUp();
        System.out.println("TestCheckPoint_StartGame PASSED......\n");
    }

    @Test
    protected static void TestFinal_FileUpload() {
        wrongArgPlayer.send(String.format("FILE_UPLOAD tag invalid\n"));
        assertEquals("Invalid arguments for command FILE_UPLOAD", wrongArgPlayer.ReadResponse());

        TestGame testGame = new TestGame(8);
        testGame.GameSetup();
        testGame.NewGame();
        testGame.JoinGame();

        testGame.DisconnectPlayer(testGame.leader);

        TestGameClient tobeLeader = testGame.players.get(1);
        assertEquals(String.format("You are the new leader for game %s!", testGame.tag), tobeLeader.ReadResponse());

        TestGameClient wasLeader = new TestGameClient("localhost:5100", testGame.leader.p.uname);
        testGame.ReconnectPlayer(wasLeader);
        testGame.leader = tobeLeader;

        wasLeader.SendHello();
        assertEquals(String.format("Welcome to Word Count %s! Resumed Game %s. Current state is FULL", wasLeader.p.uname, testGame.tag), wasLeader.ReadResponse());

        wasLeader.SendStartGame(testGame.tag);
        assertEquals(String.format("Only the leader can start the game. Please contact %s", tobeLeader.p.uname), wasLeader.ReadResponse());

        testGame.cleanUp();
        wasLeader.stop();


        testGame = new TestGame(8);
        testGame.GameSetup();
        testGame.NewGame();
        testGame.JoinGame();
        testGame.StartGame();


        TestGameClient player = testGame.players.get(new Random().nextInt(testGame.playerCount - 1) + 1);
        testGame.DisconnectPlayer(player);
        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        player = new TestGameClient("localhost:5100", player.p.uname);
        player.SendFileUpload(testGame.tag, testGame.fileName, testGame.fileSize);
        assertEquals("The game needs to start with HELLO!", player.ReadResponse());

        player.SendHello();
        testGame.ReconnectPlayer(player);
        assertEquals(String.format("Welcome to Word Count %s! Resumed Game %s. Current state is RUNNING", player.p.uname, testGame.tag), player.ReadResponse());

        player.SendFileUpload("BAD", testGame.fileName, testGame.fileSize);
        assertEquals("Game BAD doesn't exist! Please enter correct tag or try creating a new game.", player.ReadResponse());

        player.SendFileUpload(testGame.tag, testGame.fileName, testGame.fileSize);
        assertEquals(String.format("Only the leader can upload the file. Please contact %s", testGame.leader.p.uname), player.ReadResponse());

        testGame.FileUpload();


        testGame.cleanUp();
        player.stop();
        System.out.println("TestFinal_FileUpload PASSED......\n");
    }

    @Test
    protected static void TestFinal_RandomWord() {
        wrongArgPlayer.send(String.format("RANDOM_WORD tag\n"));
        assertEquals("Invalid arguments for command RANDOM_WORD", wrongArgPlayer.ReadResponse());

        TestGame testGame = new TestGame(5);
        testGame.GameSetup();
        testGame.NewGame();
        testGame.JoinGame();
        testGame.StartGame();

        // Multi game support
        TestGame secondGame = new TestGame(4);
        for (int i = 0; i < secondGame.playerCount; i++) {
            TestGame.PlayerThread t = new TestGame.PlayerThread("localhost:5100", Integer.toString(i + 99));
            secondGame.playerThreads.put(Integer.toString(i + 99), t);
            secondGame.players.add(t.player);
            t.player.SendHello();
            assertEquals(String.format("Welcome to Word Count %s! Do you want to create a new game or join an existing game?", t.player.p.uname), t.player.ReadResponse());
        }
        secondGame.leader = secondGame.players.get(0);
        secondGame.NewGame();
        secondGame.JoinGame();

        TestGameClient secPlayer = secondGame.players.get(new Random().nextInt(secondGame.playerCount - 1) + 1);
        secondGame.DisconnectPlayer(secPlayer);
        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        secPlayer = new TestGameClient("localhost:5100", secPlayer.p.uname);
        secPlayer.SendHello();
        assertEquals(String.format("Welcome to Word Count %s! Resumed Game %s. Current state is READY", secPlayer.p.uname, secondGame.tag), secPlayer.ReadResponse());
        secondGame.ReconnectPlayer(secPlayer);


        TestGameClient player = testGame.players.get(new Random().nextInt(testGame.playerCount - 1) + 1);
        testGame.DisconnectPlayer(player);
        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        testGame.FileUpload();

        player = new TestGameClient("localhost:5100", player.p.uname);
        player.SendRandomWord(testGame.tag, "random");
        assertEquals("The game needs to start with HELLO!", player.ReadResponse());

        player.SendHello();
        testGame.ReconnectPlayer(player);
        assertEquals(String.format("Welcome to Word Count %s! Resumed Game %s. Current state is RUNNING", player.p.uname, testGame.tag), player.ReadResponse());

        player.SendRandomWord("BAD", "random");
        assertEquals("Game BAD doesn't exist! Please enter correct tag or try creating a new game.", player.ReadResponse());

        player.SendRandomWord(testGame.tag, "random");
        assertEquals(String.format("Only the picker can pick the word. Please contact %s", testGame.wordSelector.p.uname), player.ReadResponse());

        testGame.RandomWord("thee");

        // the same word cannot be picked twice
        testGame.wordSelector.SendRandomWord(testGame.tag, "thee");
        String expectedErrorResponse = String.format("Word thee is not a valid choice, choose another word");
        assertEquals(expectedErrorResponse, testGame.wordSelector.ReadResponse());


        testGame.cleanUp();
//        player.stop();
        secondGame.cleanUp();
//        secPlayer.stop();
        System.out.println("TestFinal_RandomWord PASSED......\n");
    }

    @Test
    protected static void
    TestFinal_GuessCount() {
        wrongArgPlayer.send(String.format("WORD_COUNT tag\n"));
        assertEquals("Invalid arguments for command WORD_COUNT", wrongArgPlayer.ReadResponse());

        TestGame testGame = new TestGame(8);
        testGame.GameSetup();
        testGame.NewGame();

        testGame.leader.send("INVALID \n");
        assertEquals("Error! Please send the correct command.", testGame.leader.ReadResponse());

        testGame.JoinGame();
        testGame.StartGame();

        TestGameClient player = testGame.players.get(new Random().nextInt(testGame.playerCount - 1) + 1);
        String uname = player.p.uname;
        testGame.DisconnectPlayer(player);

        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        player = new TestGameClient("localhost:5100", uname);
        player.SendGuessCount(testGame.tag, 0);
        assertEquals("The game needs to start with HELLO!", player.ReadResponse());

        player.SendHello();
        assertEquals(String.format("Welcome to Word Count %s! Resumed Game %s. Current state is RUNNING", player.p.uname, testGame.tag), player.ReadResponse());
        testGame.ReconnectPlayer(player);

        testGame.FileUpload();

        player.SendGuessCount("BAD", 0);
        assertEquals("Game BAD doesn't exist! Please enter correct tag or try creating a new game.", player.ReadResponse());

        player.SendGuessCount(testGame.tag, 0);
        assertEquals(String.format("No word has been selected yet for game %s. Wait!", testGame.tag), player.ReadResponse());


        testGame.RandomWord("thee");
        testGame.GuessCount();

        testGame.cleanUp();
        player.stop();
        System.out.println("TestFinal_GuessCount PASSED......\n");
    }

    @Test
    protected static void TestFinal_Restart() {
        wrongArgPlayer.send(String.format("RESTART\n"));
        assertEquals("Invalid arguments for command RESTART", wrongArgPlayer.ReadResponse());

        TestGame testGame = new TestGame(8);
        testGame.GameSetup();
        testGame.NewGame();
        testGame.JoinGame();

        TestGameClient player = testGame.players.get(new Random().nextInt(testGame.playerCount - 1) + 1);
        testGame.DisconnectPlayer(player);
        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        player = new TestGameClient("localhost:5100", player.p.uname);
        player.SendRestart(testGame.tag);
        assertEquals("The game needs to start with HELLO!", player.ReadResponse());

        player.SendHello();
        testGame.ReconnectPlayer(player);
        assertEquals(String.format("Welcome to Word Count %s! Resumed Game %s. Current state is FULL", player.p.uname, testGame.tag), player.ReadResponse());

        player.SendRestart("BAD");
        assertEquals("Game BAD doesn't exist! Please enter correct tag or try creating a new game.", player.ReadResponse());


        player.SendRestart(testGame.tag);
        assertEquals(String.format("Only the leader can restart the game. Please contact %s", testGame.leader.p.uname), player.ReadResponse());

        testGame.Restart();

        testGame.leader.SendJoinGame(testGame.tag);
        assertEquals(String.format("Game %s is full or already in progress. Connect back later.", testGame.tag), testGame.leader.ReadResponse());

        testGame.cleanUp();
        player.stop();
        System.out.println("TestFinal_Restart PASSED......\n");
    }

    @Test
    protected static void TestFinal_Close() {
        wrongArgPlayer.send(String.format("CLOSE\n"));
        assertEquals("Invalid arguments for command CLOSE", wrongArgPlayer.ReadResponse());

        TestGame testGame = new TestGame(8);
        testGame.GameSetup();
        testGame.NewGame();
        testGame.JoinGame();

        TestGameClient player = testGame.players.get(new Random().nextInt(testGame.playerCount - 1) + 1);
        testGame.DisconnectPlayer(player);
        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        player = new TestGameClient("localhost:5100", player.p.uname);
        player.SendClose(testGame.tag);
        assertEquals("The game needs to start with HELLO!", player.ReadResponse());

        player.SendHello();
        testGame.ReconnectPlayer(player);
        assertEquals(String.format("Welcome to Word Count %s! Resumed Game %s. Current state is FULL", player.p.uname, testGame.tag), player.ReadResponse());

        player.SendClose("BAD");
        assertEquals("Game BAD doesn't exist! Please enter correct tag or try creating a new game.", player.ReadResponse());

        player.SendClose(testGame.tag);
        assertEquals(String.format("Only the leader can close the game. Please contact %s", testGame.leader.p.uname), player.ReadResponse());

        testGame.Close();
        testGame.leader.SendJoinGame(testGame.tag);
        assertEquals(String.format("Game %s doesn't exist! Please enter correct tag or try creating a new game.", testGame.tag), testGame.leader.ReadResponse());

        testGame.ClearThreads();
        player.stop();
        System.out.println("TestFinal_Close PASSED......\n");
    }


    @Test
    protected static void TestFinal_Goodbye() {
        wrongArgPlayer.send(String.format("GOODBYE invalid\n"));
        assertEquals("Invalid arguments for command GOODBYE", wrongArgPlayer.ReadResponse());


        TestGame testGame = new TestGame(6);

        TestGameClient tempPlayer = new TestGameClient("localhost:5100", "20");
        tempPlayer.SendHello();
        assertEquals(String.format("Welcome to Word Count %s! Do you want to create a new game or join an existing game?", tempPlayer.p.uname), tempPlayer.ReadResponse());

        tempPlayer.SendGoodbye();
        assertEquals("Bye!", tempPlayer.ReadResponse());
        tempPlayer.stop();

        testGame.GameSetup();
        testGame.NewGame();
        testGame.JoinGame();

        TestGameClient player = testGame.players.get(new Random().nextInt(testGame.playerCount - 1) + 1);
        testGame.DisconnectPlayer(player);
        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        player = new TestGameClient("localhost:5100", player.p.uname);
        player.SendGoodbye();
        assertEquals("The game needs to start with HELLO!", player.ReadResponse());

        player.SendHello();
        testGame.ReconnectPlayer(player);
        assertEquals(String.format("Welcome to Word Count %s! Resumed Game %s. Current state is READY", player.p.uname, testGame.tag), player.ReadResponse());

        for (int i = 6; i >= 4; i--) {
            testGame.PlayerGoodbye();
        }

        TestGameClient newPlayer = new TestGameClient("localhost:5100", "736");
        newPlayer.SendHello();
        assertEquals(String.format("Welcome to Word Count %s! Do you want to create a new game or join an existing game?", newPlayer.p.uname), newPlayer.ReadResponse());
        newPlayer.SendJoinGame(testGame.tag);
        assertEquals(String.format("Joined Game %s. Current state is READY", testGame.tag), newPlayer.ReadResponse());
        assertEquals(String.format("Game %s is ready to start", testGame.tag), testGame.leader.ReadResponse());

        testGame.ReconnectPlayer(newPlayer);
        testGame.StartGame();
        testGame.FileUpload();
        testGame.LeaderGoodbye();
        testGame.ClearThreads();

        testGame = new TestGame(6);
        testGame.GameSetup();
        testGame.NewGame();
        testGame.JoinGame();
        testGame.StartGame();
        testGame.FileUpload();

        testGame.RandomWord("thee");
        testGame.SelecterGoodbye();
        testGame.ClearThreads();

        System.out.println("TestFinal_Goodbye PASSED......\n");
    }

    public static void RunAllTests(){
        TestCheckPoint_Hello();
        TestCheckPoint_NewGame();
        TestCheckPoint_JoinGame();
        TestCheckPoint_StartGame();

        TestFinal_FileUpload();
        TestFinal_RandomWord();
        TestFinal_GuessCount();

        TestFinal_Restart();
        TestFinal_Close();
        TestFinal_Goodbye();
    }

    /**
     * Runs the tests.
     *
     * @param arguments Ignored.
     */
    public static void main(String[] arguments) {
        int test_run_count = 3;
        
        for(int i = 0; i < test_run_count; i++){
            RunAllTests();
        }

        invalidPlayer.stop();
        wrongArgPlayer.stop();
        System.out.println("CONGRATS on passing all test cases!\n");
    }
}
