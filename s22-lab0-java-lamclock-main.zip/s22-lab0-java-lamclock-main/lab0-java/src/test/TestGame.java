package test;

import org.junit.Test;

import java.io.File;
import java.util.*;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static test.TestGameClient.letters;


public class TestGame {
    private static final int MAX_PLAYERS = 8;
    private static final int MIN_PLAYERS = 4;


    public int playerCount;
    public List<TestGameClient> players;
    public List<TestGameClient> playersInGame;
    public Map<String, PlayerThread> playerThreads;
    public TestGameClient wordSelector;
    public TestGameClient leader;
    public String fileName;
    public long fileSize;
    public String tag;

    public TestGame(int playerCount) {
        players = new ArrayList<>();
        playersInGame = new ArrayList<>();
        playerThreads = new HashMap<>();
        fileName = "test.txt";
        this.playerCount = playerCount;
//        try {
//            PrintStream o = new PrintStream("test_game_log");
//            System.setOut(o);
//        } catch (FileNotFoundException e) {
//            e.printStackTrace();
//        }
    }

    public String randSeq(int n) {
        String b = "";
        for (int i = 0; i < n; i++) {
            b += letters.charAt(new Random().nextInt(letters.length()));
        }
        return b;
    }


    @Test
    protected void GameSetup() {
        for (int i = 0; i < this.playerCount; i++) {
            // create a new player thread
            PlayerThread t = new PlayerThread("localhost:5100", Integer.toString(i));

            playerThreads.put(Integer.toString(i), t);
            players.add(t.player);
            t.player.SendHello();
            String resp = t.player.ReadResponse();
            String expectedResponse = "Welcome to Word Count " + t.player.p.uname + "! Do you want to create a new game or join an existing game?";
            assertEquals(expectedResponse, resp);
        }
        leader = players.get(0);
    }

    @Test
    protected void NewGame() {
        tag = randSeq(6);
        leader.SendNewGame(tag);
        playersInGame.add(leader);
        String resp = leader.ReadResponse();
        String expectedResponse = "Game " + tag + " created! You are the leader of the game. Waiting for players to join.";
        assertEquals(expectedResponse, resp);

        TestGameClient badPlayer = players.get(1);
        badPlayer.SendNewGame(tag);
        String badResp = badPlayer.ReadResponse();
        String expectedErrorResponse = "Game " + tag + " already exists, please provide a new game tag";
        assertEquals(expectedErrorResponse, badResp);
    }

    @Test
    protected void JoinGame() {
        TestGameClient badPlayer = players.get(1);

        // test invalid game tag
        badPlayer.SendJoinGame("BAD");
        String badResp = badPlayer.ReadResponse();
        String expectedErrorResponse = "Game BAD doesn't exist! Please enter correct tag or try creating a new game.";
        assertEquals(expectedErrorResponse, badResp);

        boolean gameReady = false;

        for (int i = 1; i < players.size(); i++) {
            players.get(i).SendJoinGame(tag);
            String resp = players.get(i).ReadResponse();
            String expectedResponse;

            if (i < MIN_PLAYERS - 1) {
                expectedResponse = String.format("Joined Game %s. Current state is WAITING", tag);
                playersInGame.add(players.get(i));
            } else if (i == MAX_PLAYERS - 1) {
                playersInGame.add(players.get(i));
                expectedResponse = String.format("Joined Game %s. Current state is FULL", tag);
                gameReady = true;
            } else if (i >= MAX_PLAYERS) {
                expectedResponse = String.format("Game %s is full or already in progress. Connect back later.", tag);
                gameReady = true;
            } else {
                expectedResponse = String.format("Joined Game %s. Current state is READY", tag);
                playersInGame.add(players.get(i));
                gameReady = true;
            }

            assertEquals(expectedResponse, resp);
        }

        if (gameReady) {
            String resp = leader.ReadResponse();
            String expectedResponse = String.format("Game %s is ready to start", tag);
            assertEquals(expectedResponse, resp);
        }
    }


    @Test
    protected void StartGame() {
        leader.SendStartGame(tag);
        String expectedResponse = "Game " + tag + " is running. Please upload the file";
        assertEquals(expectedResponse, leader.ReadResponse());

        for (int i = 1; i < playersInGame.size(); i++) {
            expectedResponse = "Game " + tag + " is running. Waiting for " + leader.p.uname + " to upload the file";
            assertEquals(expectedResponse, playersInGame.get(i).ReadResponse());
        }
    }

    @Test
    protected void Restart() {
        leader.SendRestart(tag);
        for (TestGameClient p : playersInGame) {
            assertEquals("New game started!", p.ReadResponse());
        }
    }

    @Test
    protected void LeaderGoodbye() {
        leader.SendGoodbye();
        for (TestGameClient p : playersInGame) {
            String resp = p.ReadResponse();
            assertEquals("Bye!", resp);
        }

        File f = new File("./" + tag);
        f.mkdirs();
        leader.SendJoinGame(tag);
        String expectedResponse = String.format("Game %s doesn't exist! Please enter correct tag or try creating a new game.", tag);
        assertEquals(expectedResponse, leader.ReadResponse());
        f.delete();
    }

    @Test
    protected void SelecterGoodbye() {
        // word selector leaves during game
        wordSelector.SendGoodbye();
        assertEquals("Bye!", wordSelector.ReadResponse());
        playersInGame.remove(wordSelector);
        players.remove(wordSelector);


        assertEquals(String.format("Player left game. Game %s is RUNNING", tag), leader.ReadResponse());

        // other player leaves during game
        TestGameClient player = playersInGame.get(1 + new Random().nextInt(playersInGame.size() - 1));
        while (player == wordSelector) {
            player = playersInGame.get(1 + new Random().nextInt(playersInGame.size()));
        }
        player.SendGoodbye();

        String[] expectedResps = {"Bye!", String.format("Upload completed! Please select a word from %s", fileName)};
        List<String> expectedTitlesList = Arrays.asList(expectedResps);
        assertTrue(expectedTitlesList.contains((player.ReadResponse())));
        assertEquals(String.format("Player left game. Game %s is RUNNING", tag), leader.ReadResponse());
        playersInGame.remove(player);

        //close the game
        leader.SendClose(tag);
        String newSelectorResp = String.format("Upload completed! Please select a word from %s", fileName);
        TestGameClient newSelector = null;
        int selectorCount = 0, playerCount = 0;

        for (TestGameClient p : playersInGame) {
            String playerResp = p.ReadResponse();
            if (playerResp.equals("Bye!"))
                playerCount++;
            else if (playerResp.equals(newSelectorResp)) {
                selectorCount++;
                newSelector = p;
            }
        }

        assertEquals(1, selectorCount);
        assertEquals(playersInGame.size() - 1, playerCount);
        assertEquals("Bye!", newSelector.ReadResponse());
    }

    @Test
    protected void PlayerGoodbye() {
        TestGameClient player = playersInGame.get(1 + new Random().nextInt(playersInGame.size() - 1));

        player.SendGoodbye();
        playersInGame.remove(player);
        assertEquals("Bye!", player.ReadResponse());

        String expectedResponse;
        if (playersInGame.size() < MIN_PLAYERS) {
            expectedResponse = String.format("Player left game. Game %s is WAITING", tag);
        } else {
            expectedResponse = String.format("Player left game. Game %s is READY", tag);
        }
        assertEquals(expectedResponse, leader.ReadResponse());
    }

    @Test
    protected void FileUpload() {
        int selectWordCount = 0;

        File file = new File("s22-lab0-java-lamclock/lab0-java/src/test/" + fileName);
        if (file.exists()) {
            fileSize = file.length();
        }

        leader.SendFileUpload(tag, fileName, fileSize);
        String resp = leader.ReadResponse();
        String expectedResponse = "Upload completed! Waiting for word selection";
        assertEquals(expectedResponse, resp);

        int waitingCount = 1;
        for (int i = 1; i < playersInGame.size(); i++) {
            String playerResp = playersInGame.get(i).ReadResponse();
            String selectwordResponse = "Upload completed! Please select a word from " + fileName;
            if (playerResp.equals(expectedResponse)) {
                waitingCount += 1;
            } else if (playerResp.equals(selectwordResponse)) {

                selectWordCount += 1;
                this.wordSelector = playersInGame.get(i);
            }
        }

        assertEquals(1, selectWordCount);
        assertEquals(playersInGame.size() - 1, waitingCount);

        leader.SendFileUpload(tag, fileName, fileSize);
        assertEquals(String.format("Upload failed! File %s already exists for game %s", fileName, tag), leader.ReadResponse());
    }


    @Test
    protected void RandomWord(String word) {
        wordSelector.SendRandomWord(tag, "BAD");
        assertEquals("Word BAD is not a valid choice, choose another word", wordSelector.ReadResponse());

        wordSelector.SendRandomWord(tag, word);
        String expectedResponse = "Word selected is " + word + "! Guess the word count";

        for (TestGameClient player : playersInGame) {
            assertEquals(expectedResponse, player.ReadResponse());
        }
    }

    @Test
    protected void GuessCount() {
        int winnerCount = 0, loserCount = 0;
        String winnerResponse = "Congratulations you are the winner!";
        String loserResponse = "Sorry you lose! Better luck next time.";

        Random rand = new Random();

        for (TestGameClient player : playersInGame) {
            int guess = rand.nextInt((int) fileSize);
            player.SendGuessCount(tag, guess);
        }


        for (TestGameClient player : playersInGame) {
            String playerResp = player.ReadResponse();

            if (playerResp.equals(winnerResponse)) {
                winnerCount += 1;
            } else if (playerResp.equals(loserResponse)) {
                loserCount += 1;
            }
        }
        assertEquals(1, winnerCount);
        assertEquals(playersInGame.size() - 1, loserCount);

        String leaderResp = leader.ReadResponse();
        assertEquals(String.format("Game %s complete. Do you want to restart or close the game?", tag), leaderResp);
    }

    @Test
    protected void Close() {
        leader.SendClose(tag);
        for (TestGameClient player : playersInGame) {
            assertEquals("Bye!", player.ReadResponse());
        }
    }

    public void DisconnectPlayer(TestGameClient player) {
        System.out.println("Disconnect GameClient " + player.p.uname);
        playerThreads.get(player.p.uname).player.stop();
        playerThreads.get(player.p.uname).interrupt();
        playersInGame.remove(player);
        playerCount--;
    }

    public void ReconnectPlayer(TestGameClient player) {
        playersInGame.add(player);
        playerCount++;
    }

    public void ClearThreads() {
        for (PlayerThread t : playerThreads.values()) {
            t.player.stop();
            t.stop();
        }
    }

    public void cleanUp() {
        Close();
        ClearThreads();
    }

    static class PlayerThread extends Thread {
        TestGameClient player;

        PlayerThread(String addr, String name) {
            player = new TestGameClient(addr, name);
            start();
        }
    }
}



