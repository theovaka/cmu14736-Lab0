package gameServer;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.List;
import java.util.Random;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Map;


interface Server {
    int MIN_PLAYERS = 4;
    int MAX_PLAYERS = 8;

    void run();     // interface method, prints errors, no return value

    void close();   // interface method, prints errors, no return value
}


/* 
 * This is the main class which contains the implementation of the server.
 * It implements the Server interface declared above and accepts the incoming
 * connections from the players (clients) and creates new threads to handle them.
 */ 
public class GameServer implements Server {
    public String addr;
    public int port;

    // Hashmap to store all the connected players
    public ConcurrentHashMap<String, Player> ConnectedPlayers;

    // Hashmap to store information about the disconnected players
    public ConcurrentHashMap<String, String[]> DisconnectedPlayers;

    // Hashmap to store all the active games run by the server
    public ConcurrentHashMap<String, Game> ActiveGames;

    /**
     * Constructor to create a server
     * @param addr the address of the server
     */
    public GameServer(String addr) {
        String[] splitAddr = addr.split(":", 2);
        this.addr = addr;
        this.port = Integer.parseInt(splitAddr[1]);
        ConnectedPlayers = new ConcurrentHashMap<>();
        DisconnectedPlayers = new ConcurrentHashMap<>();
        ActiveGames = new ConcurrentHashMap<>();
    }

    public static void main(String[] args) {
        // start the new server on port 5100
        // NOTE: Please do not modify the port number! Changing so can cause testGameClient to fail.
        GameServer g = new gameServer.GameServer("localhost:5100");
        Runtime.getRuntime().addShutdownHook(new Thread() {
            public void run() {
                System.out.println("terminating GameServer...");
                g.close();
            }
        });

        // run the server
        g.run();
    }

    /**
     * Starts the game server
     */
    public void run() {
        try (ServerSocket serverSocket = new ServerSocket(this.port)) {
            System.out.println("Server is listening on port " + this.port);

            // Accept new connections and manage them.
            while(true){
                Socket playerSocket = serverSocket.accept();
                new GameThread(playerSocket).start();
            }
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Shuts down the game server
     */
    public void close() {
        // Close the sockets for all connected players
        for (Map.Entry<String,Player> player : ConnectedPlayers.entrySet()){
            try {
                player.getValue().socket.close();
            }
            catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * Each GameThread is expected to contain a Player, the Socket.
     */
    private class GameThread extends Thread {
        private Player player;
        private Socket socket;

        /**
         * Constructor to create a GameThread
         * @param sock
         */
        GameThread(Socket socket) {
            this.socket = socket;
        }

        public void handle_Disconnection(String[] args) {
            if (player.username != null){
                // Player has already sent hello and is identified by unique username
                ConnectedPlayers.remove(player.username);
                DisconnectedPlayers.put(player.username, new String[] {player.inGame});
            
                if (player.inGame != null && ActiveGames.get(player.inGame) != null) {
                    // Player was inside an active game and needs to be removed from it
                    Game g = ActiveGames.get(player.inGame);
                    g.removePlayer(player);

                    // In case the player was the leader, a new leader needs to be selected
                    if (player.is_leader) {
                        player.is_leader = false;
                        g.newLeader();
                    }
                }
            }
        }

        /*
         * The function implements all necessary functionality when the player
         * sends the commnad HELLO to the server.
         */
        public void handle_HELLO(String[] args) {
            // Error checks
            if (args.length > 2) {
                player.sendMessage("Invalid arguments for command HELLO\n");
            }
            else if (args.length < 2) {
                player.sendMessage("Invalid user name. Try again.\n");
            }
            else {
                if (DisconnectedPlayers.get(args[1]) != null) {
                    // Player has been disconnected before and attempts to connect again
                    player.setUsername(args[1]);
                    player.restore(DisconnectedPlayers.get(args[1]));
                    DisconnectedPlayers.remove(args[1]);
                    ConnectedPlayers.put(args[1], player);

                    if (player.inGame != null && ActiveGames.get(player.inGame) != null) {
                        // If player was in a game before disconnection that it is still
                        // active, resume it for the player
                        Game g = ActiveGames.get(player.inGame);
                        g.addPlayer(player);
                        player.sendMessage("Welcome to Word Count " + player.username + "! Resumed Game " + player.inGame + ". Current state is " + g.status +'\n');
                    }
                    else {
                        player.sendMessage("Welcome to Word Count " + player.username + "! Do you want to create a new game or join an existing game?\n");
                    }
                }
                else {
                    // New connected Player
                    player.setUsername(args[1]);
                    player.sendMessage("Welcome to Word Count " + args[1] + "! Do you want to create a new game or join an existing game?\n");
                    ConnectedPlayers.put(args[1], player);
                }
            }
        }

        /*
         * The function implements all necessary functionality when the player
         * sends the commnad NEW_GAME to the server.
         */
        public void handle_NEW_GAME(String[] args) {
            // Error checks
            if (args.length != 2) {
                player.sendMessage("Invalid arguments for command NEW_GAME\n");
            }
            else if (player.username == null) {
                player.sendMessage("The game needs to start with HELLO!\n");
            }
            else {
                if (ActiveGames.get(args[1]) != null) {
                    // Game already exists
                    player.sendMessage("Game " + args[1] + " already exists, please provide a new game tag\n");
                }
                else {
                    // New Game Created
                    Game g = new Game(args[1], player);
                    // Assign the player who created the game as the leader
                    player.is_leader = true;
                    ActiveGames.put(args[1], g);
                    player.sendMessage("Game " + args[1] + " created! You are the leader of the game. Waiting for players to join.\n");
                }                          
            }
        }

        /*
         * The function implements all necessary functionality when the player
         * sends the commnad JOIN_GAME to the server.
         */
        public void handle_JOIN_GAME(String[] args) {
            // Error checks
            if (args.length != 2) {
                player.sendMessage("Invalid arguments for command JOIN_GAME\n");
            }
            else if (player.username == null) {
                player.sendMessage("The game needs to start with HELLO!\n");
            }
            else if (ActiveGames.get(args[1]) == null) {
                player.sendMessage("Game " + args[1] + " doesn't exist! Please enter correct tag or try creating a new game.\n");
            }
            else {
                // Try to join the existing game
                Game g = ActiveGames.get(args[1]);
                String status = g.status;

                if (status.equals("FULL") || g.started) {
                    // The game is full or has already started, do not allow to join
                    player.sendMessage("Game " + args[1] + " is full or already in progress. Connect back later.\n");
                }
                else {
                    // Join specified game
                    g.addPlayer(player);
                    player.sendMessage("Joined Game " + args[1] + ". Current state is " + g.status + '\n');
                    
                    // If game status changes from WAITING to READY after current
                    // player joined, inform the leader that the game is ready to start
                    if (status.equals("WAITING") && g.status.equals("READY")) {
                        g.leader.sendMessage("Game " + g.tag + " is ready to start\n");
                    }
                }
            }
        }

        /*
         * The function implements all necessary functionality when the player
         * sends the commnad START_GAME to the server.
         */
        public void handle_START_GAME(String[] args) {
            // Error checks
            if (args.length != 2) {
                player.sendMessage("Invalid arguments for command START_GAME\n");
            }
            else if (ActiveGames.get(args[1]) == null) {
                player.sendMessage("Game " + args[1] + " doesn't exist! Please enter correct tag or try creating a new game.\n");
            }
            else if (player != ActiveGames.get(args[1]).leader) {
                player.sendMessage("Only the leader can start the game. Please contact " + ActiveGames.get(args[1]).leader.username + '\n');
            }
            else if (ActiveGames.get(args[1]).playerCount < MIN_PLAYERS) {
                int remaining = MIN_PLAYERS - ActiveGames.get(args[1]).playerCount;
                player.sendMessage("Can't start the game " + ActiveGames.get(args[1]).tag + ", waiting for " + String.valueOf(remaining) + " more players.\n");
            }
            else if (ActiveGames.get(args[1]).started) {
                player.sendMessage("Game " + ActiveGames.get(args[1]).tag + " has already started! Please try creating a new game.\n");
            }
            else {
                // Start the game
                Game g = ActiveGames.get(args[1]);
                g.started = true;
                player.is_leader = true;
                g.updateState();
                
                // Inform the leader and the other players that the game has started
                g.leader.sendMessage("Game " + g.tag + " is running. Please upload the file\n");
                for (Player p : g.players) {
                    if (p != g.leader) {
                        p.sendMessage("Game " + g.tag + " is running. Waiting for " + g.leader.username + " to upload the file\n");
                    }                        
                }
            }
        }

        /*
         * The function implements all necessary functionality when the player
         * sends the commnad FILE_UPLOAD to the server.
         */
        public void handle_FILE_UPLOAD(String[] args) {
            // Error checks
            if (args.length != 5) {
                player.sendMessage("Invalid arguments for command FILE_UPLOAD\n");
            }
            else if (player.username == null) {
                player.sendMessage("The game needs to start with HELLO!\n");
            }
            else if (ActiveGames.get(args[1]) == null) {
                player.sendMessage("Game " + args[1] + " doesn't exist! Please enter correct tag or try creating a new game.\n");
            }
            else if (player != ActiveGames.get(args[1]).leader) {
                player.sendMessage("Only the leader can upload the file. Please contact " + ActiveGames.get(args[1]).leader.username + '\n');
            }
            else if (ActiveGames.get(args[1]).fileName != null) {
                player.sendMessage("Upload failed! File " + args[2] + " already exists for game " + args[1] + '\n');
            }
            else {
                // New File Upload
                Game g = ActiveGames.get(args[1]);
                g.fileName = args[2];
                g.fileSize = Integer.parseInt(args[3]);
                g.fileData = args[4];
                g.fileDataWords = Arrays.asList(g.fileData.split(" "));

                // Randomly select a player to pick a word and inform them to do so
                g.wordSelector =  g.players.get(g.rng.nextInt(g.playerCount-1) + 1);
                g.wordSelector.sendMessage("Upload completed! Please select a word from " + g.fileName + '\n');
                g.wordSelector.is_wordSelector = true;

                // Inform all other players in the game that the upload of the file is complete
                for (Player p : g.players) {
                    if (p != g.wordSelector) {
                        p.sendMessage("Upload completed! Waiting for word selection\n");
                    }
                }
            }
        }

        /*
         * The function implements all necessary functionality when the player
         * sends the commnad RANDOM_WORD to the server.
         */
        public void handle_RANDOM_WORD(String[] args) {
            // Error checks
            if (args.length != 3) {
                player.sendMessage("Invalid arguments for command RANDOM_WORD\n");
            }
            else if (player.username == null) {
                player.sendMessage("The game needs to start with HELLO!\n");
            }
            else if (ActiveGames.get(args[1]) == null) {
                player.sendMessage("Game " + args[1] + " doesn't exist! Please enter correct tag or try creating a new game.\n");
            }
            else if (player != ActiveGames.get(args[1]).wordSelector) {
                player.sendMessage("Only the picker can pick the word. Please contact " + ActiveGames.get(args[1]).wordSelector.username + '\n');
            }
            else {
                Game g = ActiveGames.get(args[1]);
                if ((g.fileDataWords.indexOf(args[2]) == -1) || g.randomWordsUsed.indexOf(args[2]) != -1) {
                    // Selected word does not exist in the file or has been selected
                    // in a previous round of the game. New word has to be selected.
                    player.sendMessage("Word " + args[2] + " is not a valid choice, choose another word\n");
                }
                else {
                    // Selected word is acceptable
                    g.randomWord = args[2];
                    g.randomWordsUsed.add(args[2]);

                    // Inform all players in the game to send their guess
                    for (Player p : g.players) {
                        p.sendMessage("Word selected is " + g.randomWord + "! Guess the word count\n");
                    }
                }
            }
        }

        /*
         * The function implements all necessary functionality when the player
         * sends the commnad WORD_COUNT to the server.
         */
        public void handle_WORD_COUNT(String[] args) {
            // Error checks
            if (args.length != 3) {
                player.sendMessage("Invalid arguments for command WORD_COUNT\n");
            }
            else if (player.username == null) {
                player.sendMessage("The game needs to start with HELLO!\n");
            }
            else if (ActiveGames.get(args[1]) == null) {
                player.sendMessage("Game " + args[1] + " doesn't exist! Please enter correct tag or try creating a new game.\n");
            }
            else if (ActiveGames.get(args[1]).randomWord == null) {
                player.sendMessage("No word has been selected yet for game " + args[1] + ". Wait!\n");
            }
            else {
                player.guess = Integer.parseInt(args[2]);
                Game g = ActiveGames.get(args[1]);

                // Check if all players in the game have sent their guess
                if (g.guessCompleted()) {
                    // Calculate the winner of the game
                    Player winner = g.getWinner();
                    winner.sendMessage("Congratulations you are the winner!\n");

                    // Inform all other players that they lost this round of the game
                    for (Player p: g.players) {
                        if (p != winner) {
                            p.sendMessage("Sorry you lose! Better luck next time.\n");
                        }
                    }

                    // Inform leader that the game is complete
                    g.leader.sendMessage("Game " + g.tag + " complete. Do you want to restart or close the game?\n");
                    g.status = "COMPLETE";
                    g.started = false;
                }
            }
        }

        /*
         * The function implements all necessary functionality when the player
         * sends the commnad RESTART to the server.
         */
        public void handle_RESTART(String[] args) {
            // Error checks
            if (args.length != 2) {
                player.sendMessage("Invalid arguments for command RESTART\n");
            }
            else if (player.username == null) {
                player.sendMessage("The game needs to start with HELLO!\n");
            }
            else if (ActiveGames.get(args[1]) == null) {
                player.sendMessage("Game " + args[1] + " doesn't exist! Please enter correct tag or try creating a new game.\n");
            }
            else {
                Game g = ActiveGames.get(args[1]);
                if (player != g.leader) {
                    player.sendMessage("Only the leader can restart the game. Please contact " + g.leader.username + '\n');
                }
                else {
                    // Restart game
                    g.restart();
                }
            }
        }

        /*
         * The function implements all necessary functionality when the player
         * sends the commnad GOODBYE to the server.
         */
        public void handle_GOODBYE(String[] args) {
            // Error checks
            if (args.length != 1) {
                player.sendMessage("Invalid arguments for command GOODBYE\n");
            }
            else if (player.username == null) {
                player.sendMessage("The game needs to start with HELLO!\n");
            }
            else {
                if (player.inGame != null) {
                    Game g = ActiveGames.get(player.inGame);
                    
                    // If player is the leader of an active game, close this game.
                    if (player.is_leader) {
                        // Close the game
                        for (Player p : g.players) {
                            p.sendMessage("Bye!\n");
                            p.reset();
                        }
                        ActiveGames.remove(g.tag);
                        ConnectedPlayers.remove(player);
                    }
                    // If player is the word selector of an active game, pick another player for this role.
                    else if (player == g.wordSelector) {
                        g.removePlayer(player);
                        ConnectedPlayers.remove(player);
                        g.leader.sendMessage("Player left game. Game " + g.tag + " is " + g.status + '\n');
                        
                        // Randomly select another player to pick a word and inform them to do so
                        g.wordSelector =  g.players.get(g.rng.nextInt(g.playerCount-1) + 1);
                        g.wordSelector.sendMessage("Upload completed! Please select a word from " + g.fileName + '\n');
                        player.sendMessage("Bye!\n");
                    }
                    // If player has not a special role in the game, remove them and inform the leader.
                    else {
                        g.removePlayer(player);
                        ConnectedPlayers.remove(player);
                        g.leader.sendMessage("Player left game. Game " + g.tag + " is " + g.status + '\n');
                        player.sendMessage("Bye!\n");
                    }
                }
                else {
                    player.sendMessage("Bye!\n");
                }
            }
        }

        /*
         * The function implements all necessary functionality when the player
         * sends the commnad CLOSE to the server.
         */
        public void handle_CLOSE(String[] args) {
            // Error checks
            if (args.length != 2) {
                player.sendMessage("Invalid arguments for command CLOSE\n");
            }
            else if (player.username == null) {
                player.sendMessage("The game needs to start with HELLO!\n");
            }
            else if (ActiveGames.get(args[1]) == null) {
                player.sendMessage("Game " + args[1] + " doesn't exist! Please enter correct tag or try creating a new game.\n");
            }
            else {
                Game g = ActiveGames.get(args[1]);
                if (player != g.leader) {
                    player.sendMessage("Only the leader can close the game. Please contact " + g.leader.username + '\n');
                }
                else {
                    // Remove all players from the game, inform them and reset their state
                    for (Player p : ActiveGames.get(args[1]).players) {
                        p.reset();
                        p.sendMessage("Bye!\n");
                    }

                    // Remove game from the hashmap of active games
                    ActiveGames.remove(args[1]);
                }
            }
        }

        /*
         * Main function that implements the player thread functionality until it terminates.
         * Receives input from the player (client) thorugh a stream over a network socket,
         * updates the server state accordingly and writes the output to another stream over a
         * netwrok socket to be received by the player.
         */
        public void run() {
            // System.out.println("Just connected to " + socket.getRemoteSocketAddress());
            player = new Player(socket);
            
            try {
                // This is an infinite loop that runs until the player disconnects
                // and handles all interactions between the player and the server
                while (true) {
                    // Read a new command from the player socket
                    String[] args = player.getCommand();
                    
                    if (args.length == 0){
                        socket.close();
                        break;
                    }
                    
                    String cmd = args[0];

                    // Act based on the command the player issued
                    if (cmd.equals("Disconnection")) {
                        // Special case when the getCommand() function triggers an exception
                        // because the read failed due to the disconnection of the player socket
                        handle_Disconnection(args);
                        socket.close();
                        break;
                    }
                    else if (cmd.equals("HELLO")) {
                        handle_HELLO(args);
                    }
                    else if (cmd.equals("NEW_GAME")) {
                        handle_NEW_GAME(args);
                    }
                    else if (cmd.equals("JOIN_GAME")) {
                        handle_JOIN_GAME(args);
                    }
                    else if (cmd.equals("START_GAME")) {
                        handle_START_GAME(args);
                    }
                    else if (cmd.equals("FILE_UPLOAD")) {
                        handle_FILE_UPLOAD(args);
                    }
                    else if (cmd.equals("RANDOM_WORD")) {
                        handle_RANDOM_WORD(args);
                    }
                    else if (cmd.equals("WORD_COUNT")) {
                        handle_WORD_COUNT(args);
                    }
                    else if (cmd.equals("RESTART")) {
                        handle_RESTART(args);
                    }
                    else if (cmd.equals("GOODBYE")) {
                        handle_GOODBYE(args);
                    }
                    else if (cmd.equals("CLOSE")) {
                        handle_CLOSE(args);
                    }
                    else {
                        player.sendMessage("Error! Please send the correct command.\n");
                    }
                } 
            }
            catch (IOException | ArrayIndexOutOfBoundsException e) {
                e.printStackTrace();
            }
        }
    }
}

/**
 * Player object
 */
class Player {
    public String username;
    public Socket socket;
    public BufferedReader in;
    public BufferedWriter out;
    public Integer guess;
    public Boolean is_leader;
    public Boolean is_wordSelector;
    public String inGame;


     /**
     * Constructor to create a Player
     * @param socket the socket bound to the player
     */
    public Player(Socket socket) {
        this.socket = socket;
        try {
            this.in = new BufferedReader(new InputStreamReader(this.socket.getInputStream()));
            this.out = new BufferedWriter(new OutputStreamWriter(this.socket.getOutputStream()));
            this.is_leader = false;
            this.is_wordSelector = false;
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    /* 
     * Restores the player state after reconnection.
     * Restores game that the player was in before disconnection and the flags
     * for the leader and word selector to FALSE because the player will definitely
     * not be responsible for either of these roles after reconnection.
     */
    public void restore(String[] args) {
        inGame = args[0];
        is_leader = false;
        is_wordSelector = false;
    }

    /*
     * Resets the player state after a game has ended
     */
    public void reset() {
        inGame = null;
        is_leader = false;
        is_wordSelector = false;
    }

    /*
     * Set the username for the player
     */
    public void setUsername (String name) {
        this.username = name;
    }

    /*
     * Writes a message (line) to the output stream of the player socket
     */
    public void sendMessage(String msg) {
        try {
            out.write(msg);
            out.flush();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    /*
     * Parses a new line from the input stream of the player socket and returns
     * the relevant arguments a list of strings. if the read operation fails 
     * because of the socket disconnection, an excpetion is triggered because the
     * variable line will be NULL and the function returns the argument
     * 'Disconnection' so that the main program handles the player disconnection.
     */
    public String[] getCommand() {
        try {
            String line = in.readLine();
            String[] args = line.split(" ");
            if (line.startsWith("FILE_UPLOAD") && args.length >= 5) {
                String fileContent = line.substring(line.indexOf(args[4]));
                return new String[]{args[0], args[1], args[2], args[3], fileContent};
            }

            return args;
        }
        catch (IOException e) {
            return new String[0];
        }
        catch (NullPointerException e) {
            // Socket disconnected and therefore read failed (line is NULL)
            return new String[] {"Disconnection"};
        }
    }
}

/**
 * Game object to keep track of the game status
 */
class Game {
    public static int MIN_PLAYERS = 4;
    public static int MAX_PLAYERS = 8;
    
    public String tag;
    public String status;
    public boolean started;

    public int playerCount;
    public List<Player> players;

    public Player wordSelector;
    public Player leader;

    public String fileName;
    public long fileSize;
    public String fileData;
    public List<String> fileDataWords;

    public Random rng;
    public String randomWord;
    public List<String> randomWordsUsed;

    /*
     * Update the state of the game
     * The state will be one of the following:
     * -> RUNNING: The game is runnig
     * -> WAITING: Players in game are < MIN_PLAYERS
     * -> READY: Players in game are greater or equal to MIN_PLAYERS but less than MAX_PLAYERS
     * -> FULL: Players in game are equal to MAX_PLAYERS
     */
    public void updateState() {
        if (started) {
            status = "RUNNING";
        }
        else {
            if (playerCount < MIN_PLAYERS) {
                status = "WAITING";
            }
            else if (playerCount < MAX_PLAYERS) {
                status = "READY";
            }
            else {
                status = "FULL";
            }
        }
    }

    /*
     * Remove a player from the game and update its state
     */
    public void removePlayer(Player p) {
        players.remove(p);
        playerCount--;
        p.inGame = null;
        updateState();
    }

    /*
     * Add a new player to the game and update its state
     */
    public void addPlayer(Player p) {
        if (playerCount < MAX_PLAYERS) {
            players.add(p);
            playerCount+=1;
            p.inGame = this.tag;
            updateState();
        }
    }

    /*
     * Restart the game, reset its state and inform all the players in it
     */
    public void restart() {
        // Reset the word selector because a new one has to be picked for the new round
        for (Player p: players) {
            if (p.is_wordSelector) {
                p.is_wordSelector = false;
            }
            p.sendMessage("New game started!\n");
        }
        wordSelector = null;
        randomWord = null;
        updateState();
    }

    /*
     * Pick the first player in the player list as the new leader and inform them
     */
    public void newLeader() {
        Player newLeader =  players.get(0);
        newLeader.is_leader = true;
        leader = newLeader;
        newLeader.sendMessage("You are the new leader for game " + tag + "!\n");
    }

    /*
     * Check if all players in the game have sent their guess and return True/False respectively
     */
    public boolean guessCompleted() {
        for (Player p: players) {
            if (p.guess == null){
                return false;
            }
        }

        // All players have sent their guess
        return true;
    }

    /*
     * Calculate and return the winner of the game
     */
    public Player getWinner() {
        Integer correct = 0;
        // Iterate over the words of the uploaded file to calculate
        // the number of occurancies of the selected word in it (correct guess)
        for (String s: fileDataWords) {
            if (s.equals(randomWord)) {
                correct++;
            }
        }
        
        int min = Integer.MAX_VALUE;
        Player winner = null;
        // Iterate over the players in the game to calculate the player
        // with the closest guess to the correct number of occurancies
        for (Player p: players) {
            if (Math.abs(p.guess - correct) < min) {
                min = Math.abs(p.guess - correct);
                winner = p;
            }
        }
        return winner;
    }

     /**
     * Constructor to create a Game
     * @param tag the tag of the game
     * @param leader the leader of the game
     */
    public Game(String tag, Player leader) {
        this.tag = tag;
        this.status = "WAITING";
        this.started = false;

        this.players = new ArrayList<>();
        this.playerCount = 0;

        this.rng = new Random();
        this.randomWordsUsed = new ArrayList<>();

        // Assign leader for the game
        this.leader = leader;
        this.addPlayer(leader);
    }
}