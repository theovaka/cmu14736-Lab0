# 14736 Distributed Systems - Lab 0

## Setting up your Java Environment

### IDE

If you already have an IDE set up for Java programming, the only additional piece needed for this lab is to enable and configure the JUnit unit testing framework. This is supported by default in **[Intellij](https://www.jetbrains.com/idea/download/#section=mac)**, so that may be the best choice if you do not yet have an IDE installed.

### CLI

If you prefer to do your Java programming using the command-line interface in our Ubuntu VM, you'll need to ensure you have a suitable JDK. This can be done by running the following commands in a terminal.

```
sudo apt update; sudo apt -y upgrade
sudo apt install default-jdk
```

Our tests use a package `junit4` that is provided in the `lib` directory of the starter code repo. You can either manually link this library into the test code at compile time, or you can define a persistent environment variable to handle that for you.  For the latter, add the following line at the end of the file `/home/ini742/.bashrc`:
```
export CLASS_PATH=/path/to/repo/lab0-java/lib/junit4.jar:.
```
where `/path/to/repo` is the absolute path to the location of your lab repository.

## Running the Game Server and Tests

The game server will run independently of the test suite, so you only need to use the test suite to see if your implementation can pass the tests.  Until you're ready for testing, you can use standard debugging techniques, mimic a client using netcat (`nc`), or create a `GameClient.java` program.

### Game Server

Running the game server itself does not depend on the test suite, so you will run this just like any normal Java program, using your IDE or the `javac/java` commands at the CLI in a separate terminal, i.e., from the lab `src` directory, run
```
javac gameServer/GameServer.java
java gameServer.GameServer
```

### Test setup

#### Using Intellij or another IDE:
Navigate to `src/test/ConformanceTest.java` and run the test suite.  

#### CLI testing
To compile and run the test code using JUnit, you need to include the JUnit library at compile and at run time. This can be done from the lab's `src` directory with the commands:
```
javac -cp $CLASS_PATH test/*.java
java -cp $CLASS_PATH test.ConformanceTest
```
If everything is working, you should see the server print an initialization message in its terminal, and the test suite will output some form of `FAIL` message in its terminal (unless you've already done some implementation, then maybe you'll see a `PASS` message).

## Need any help?
As usual, don't hesitate to contact the course staff via Piazza or Slack, or attend our office hours as listed on Canvas.
